//global
import "./components/lenis.js";
import "./components/navbar.js";
import "./components/link-reveal.js";
import "./components/image-reveal.js";
import "./components/join.js";

import "./components/home-hero.js";
import "./components/projects-mask.js";
import "./components/custom-cursor.js";
import "./components/values.js";
import "./components/process.js";
import "./components/project-gallery.js";

import "./components/split-text.js";
